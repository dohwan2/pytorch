#pragma once

namespace torch { namespace jit {

void initJITBindings(PyObject *module);

}}
