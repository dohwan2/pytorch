#pragma once

namespace torch { namespace cuda { namespace python {

void initCommMethods(PyObject *module);

}}}
