#include <Python.h>

namespace torch { namespace jit { namespace script {

void initTreeViewBindings(PyObject *module);

}}} // namespace torch::jit::script

