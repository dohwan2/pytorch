#undef TH_GENERIC_FILE
#undef LIBRARY_STATE
#undef LIBRARY_STATE_NOARGS

#undef THPTensor_
#undef THPTensor_stateless_
#undef THPTensor
#undef THPTensorStr
#undef THPTensorBaseStr
#undef THPTensorClass

#undef THPTensorStatelessType
#undef THPTensorStateless
#undef THPTensorType

#undef THPStorage_
#undef THPStorage
#undef THPStorageBaseStr
#undef THPStorageStr
#undef THPStorageClass
#undef THPStorageType

#undef THStorage
#undef THStorage_
#undef THTensor
#undef THTensor_

#undef THStoragePtr
#undef THPStoragePtr
#undef THTensorPtr
#undef THPTensorPtr

#undef THHostTensor
#undef THHostTensor_
#undef THHostStorage
#undef THHostStorage_
