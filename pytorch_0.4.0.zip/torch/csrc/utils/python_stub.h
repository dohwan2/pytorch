#pragma once

struct _object;
typedef _object PyObject;
