// Intentionally blank so I get a compile_commands.json entry for the header
