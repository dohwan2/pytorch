#pragma once

#include <Python.h>

extern PyMethodDef DataLoaderMethods[];
