#include <Python.h>

namespace torch { namespace autograd {

void initNNFunctions(PyObject* module);

}} // namespace torch::autograd
